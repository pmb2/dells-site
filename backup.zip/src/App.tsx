import React from 'react';
import LuxuryDetailing from './components/LuxuryDetailing';

const App: React.FC = () => {
  return (
    <div>
      <LuxuryDetailing />
    </div>
  );
}

export default App;
