import React from "react";

const HeroSection: React.FC = () => {
    return (
        <section className="mt-32 max-md:mt-10 max-md:max-w-full text-center">
            <h1 className="text-8xl leading-none text-white max-md:text-4xl font-bold">
                Ultimate Detailing Experience
            </h1>
            <p className="mt-8 text-xl leading-8 text-neutral-200 max-md:text-base max-md:mt-4">
                Experience the prestige of a professionally detailed car,<br/>
                radiating elegance and refinement at every turn.
            </p>
            <div className="flex justify-center gap-4 px-5 mt-11 text-xl leading-9 text-white max-md:mt-6">
                <button className="px-8 py-3 bg-white text-black rounded-md hover:bg-gray-200">
                    Let's connect
                </button>
                <img
                    loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/7eaf987ffdaaa4e03d82fb652b6f24618a6224be55798083b968f92c75ac0d8d?apiKey=595dc89cc648492db3d301f5cc8cfcbe&"
                    alt=""
                    className="shrink-0 w-4 h-4 border-2 border-white border-solid aspect-square stroke-[2px] stroke-white"
                />
            </div>
            <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/3e160042aa6a217f6d66a2173b5ab0f2c46a1f031f8297ff4170e05551870301?apiKey=595dc89cc648492db3d301f5cc8cfcbe&"
                alt="Luxury car detailing"
                className="self-stretch mt-20 w-full aspect-[2.56] max-md:mt-10 max-md:max-w-full"
            />
        </section>
    );
};

export default HeroSection;
